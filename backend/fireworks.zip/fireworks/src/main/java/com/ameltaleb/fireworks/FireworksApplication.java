package com.ameltaleb.fireworks;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class FireworksApplication {

	public static void main(String[] args) {
		SpringApplication.run(FireworksApplication.class, args);
	}

}
